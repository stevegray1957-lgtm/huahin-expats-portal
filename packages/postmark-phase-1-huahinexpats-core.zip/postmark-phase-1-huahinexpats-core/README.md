# Postmark Phase 1 — Apply Package

This package contains everything needed to apply Phase 1 of the Postmark transactional email work to the `huahinexpats-core` WordPress plugin.

**Do not just copy the files.** Read [`POSTMARK_PHASE_1_APPLY_CHECKLIST.md`](./POSTMARK_PHASE_1_APPLY_CHECKLIST.md) first — it has the exact step-by-step, the abort criteria (§7), and the rollback (§8).

---

## What's in this package

```
postmark-phase-1-huahinexpats-core/
├── README.md                                  (this file — apply + rollback summary)
├── POSTMARK_PHASE_1_APPLY_CHECKLIST.md         (operator checklist — read this)
├── POSTMARK_PHASE_1_TRANSACTIONAL_EMAIL_REPORT.md  (what changed, why)
└── plugin-files/
    ├── huahinexpats-core/
    │   ├── huahinexpats-core.php               (modified)
    │   └── inc/
    │       ├── admin-email-settings.php        (NEW)
    │       ├── deliverability.php              (modified)
    │       ├── email-identity.php              (modified)
    │       ├── premium.php                     (modified)
    │       └── stripe.php                      (modified)
    └── scripts/
        └── postmark-phase-1-smoke-test.sh      (WP-CLI smoke test)
```

All PHP files have been syntax-checked with `php -l` in the staging environment.

## What this package does NOT contain

- Postmark Server API tokens (you paste those in WP Admin after applying).
- Any other secrets, credentials, or `.env` content.
- Hidden files (`.git`, `.DS_Store`, etc.).
- Database changes (none required).
- The wider HuaHinExpats codebase — only the six files that changed.

If you find anything secret-looking in this zip, treat it as a packaging bug. Do not proceed; report immediately.

---

## Apply summary (full procedure is in the checklist)

1. Back up `wp-content/plugins/huahinexpats-core/` to a timestamped tarball.
2. Copy the six files from `plugin-files/huahinexpats-core/` into the live plugin directory.
3. Confirm activation and run the smoke test:
   ```
   cd <wp-root>
   bash <path-to-this-unzipped-dir>/plugin-files/scripts/postmark-phase-1-smoke-test.sh
   ```
4. Configure Postmark credentials in WP Admin → Hua Hin Expats → Email Settings.
5. Click "Send test email" and verify delivery.
6. Confirm the §7 "Do not continue if" conditions are all clear in the apply checklist.

**Total time to apply and verify: ~15–30 minutes.**

---

## Rollback summary (full procedure in the checklist §8)

1. Restore the backup tarball into `wp-content/plugins/huahinexpats-core/`.
2. (Optional) Delete the new `hhe_email_*` options via WP-CLI.
3. Verify the plugin still activates and password reset still works.
4. Report the abort condition and the PHP error log entry that triggered it.

---

## What's intentionally not in Phase 1

This package implements Phase 1 only. The following are deferred to later sprints:

- Per-Server Postmark isolation (separate HHE Info / HHE Accounts / HHE Legal Servers).
- Bounce webhook (`/wp-json/hhe/v1/email-bounce`).
- DMARC progression to `p=quarantine` / `p=reject` (operator-managed, ~6 weeks after Phase 1 cutover).
- Newsletter / marketing automation changes.
- Airwallex payment integration.
- Google Places / trusted-source enrichment.
- Encrypted-at-rest secrets.

Each of those has a separate design document in the Portal repo `docs/` directory.

---

## Backwards compatibility

- Existing `hhe_smtp_*` settings are preserved at the option-key level. Sites running the previous single-account SMTP setup keep working unchanged.
- `HHE_EMAIL_INFO`, `HHE_EMAIL_ACCOUNTS`, `HHE_EMAIL_LEGAL`, `HHE_EMAIL_FROM_NAME` constants are unchanged. `wp-config.php` overrides continue to work.
- `hhec_email_send()` signature is unchanged. All existing callers continue to work.
- WordPress core mail (password reset, new-user notifications, admin emails) still routes via `info@` through the SMTP relay.

---

## Acceptance criteria

You can consider Phase 1 successfully applied when:

- The plugin activates without errors.
- The new Email Settings page renders.
- A test email delivers via Postmark within 60 seconds.
- The password field is empty (write-only) after save.
- WordPress password reset still delivers.
- The Phase 1 report's §9 checklist is all green.

If any check fails, follow the rollback procedure (§8 of the checklist). Do not partially apply.
